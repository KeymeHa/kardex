<div id="modal-Notificaciones" class="modal fade" role="dialog">
   <div class="modal-dialog modal-lg">
    <div class="modal-content">

        <div class="modal-header" style="background:#00A65A; color:white">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" >Notificaciones: <span id="tituloNotificaciones"></span></h4>
        </div>

        <div class="modal-body" id="bodyNotificaciones">


        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Cerrar</button>
        </div>

    </div>
  </div>
</div>