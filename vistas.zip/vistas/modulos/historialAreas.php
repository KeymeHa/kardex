<div class="content-wrapper">
     <?php
    include "bannerConstruccion.php";
  ?>
  <section class="content-header">
    <h1>    
      Historial Areas  
    </h1>
    <ol class="breadcrumb">    
      <li><a href="inicio"><i class="fa fa-dashboard"></i> Inicio</a></li>
      <li><a href="#">Historiales</a></li>     
      <li class="active">Areas</li>  
    </ol>
  </section>
  <section class="content">
    <div class="box">
      <div class="box-header with-border">
       
      </div>
      <div class="box-body">       
      
      </div>
    </div>
  </section>
</div>