<div class="content-wrapper">
     <?php
    include "bannerConstruccion.php";
  ?>
  <section class="content-header">
    <h1>    
      Pedidos 
    </h1>
    <ol class="breadcrumb">    
      <li><a href="inicio"><i class="fa fa-dashboard"></i> Inicio</a></li>
      <li><a href="#">Generaciones</a></li>     
      <li class="active">Pedidos</li>  
    </ol>
  </section>
  <section class="content">
    <div class="box">
      <div class="box-header with-border">
       
      </div>
      <div class="box-body">       
      
      </div>
    </div>
  </section>
</div>