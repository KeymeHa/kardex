<?php
echo'<input type="hidden" id="accionID" accionId="'.$_SESSION['id'].'" readonly>';
?>