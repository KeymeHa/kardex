<footer class="main-footer">
		
		<strong>Copyright &copy; 2021.</strong>

		Desarrollado por KB Todos los derechos reservados.


</footer>